-- 009 會員平台 v0.1：請在全新 Supabase 專案的 SQL Editor 執行一次。
-- 金額與 CV 僅為帳務記錄，不含自動計算、付款、轉讓或兌換。
-- 必須由可信任的伺服器／管理流程新增記錄，絕不可將 service_role 金鑰放在網頁中。
create extension if not exists pgcrypto;

create table if not exists public.member_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '009 會員' check (char_length(display_name) <= 80),
  referral_code text not null unique default upper(substr(replace(gen_random_uuid()::text,'-',''),1,10)),
  inviter_code text check (char_length(inviter_code) <= 32),
  status text not null default 'active' check (status in ('active','suspended')),
  created_at timestamptz not null default now()
);

create table if not exists public.member_orders (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.member_profiles(id),
  order_ref text not null unique,
  description text not null default '會員消費',
  paid_amount numeric(14,2) not null check (paid_amount >= 0),
  status text not null check (status in ('pending','paid','refunded','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.cv_ledger (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.member_profiles(id),
  delta numeric(16,4) not null check (delta <> 0),
  entry_type text not null check (entry_type in ('grant','adjustment','redeem','transfer_in','transfer_out')),
  description text not null default '',
  reference_id text,
  created_at timestamptz not null default now()
);

create table if not exists public.rebate_ledger (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.member_profiles(id),
  delta numeric(16,2) not null check (delta <> 0),
  unit text not null check (unit in ('credit','P','RC','TWD')),
  entry_type text not null check (entry_type in ('grant','adjustment','redeem','transfer_in','transfer_out')),
  description text not null default '',
  reference_id text,
  created_at timestamptz not null default now()
);

create table if not exists public.lv_positions (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.member_profiles(id),
  position_ref text not null unique,
  tier integer check (tier between 1 and 10),
  status text not null default 'pending' check (status in ('pending','active','closed')),
  description text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.member_vouchers (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.member_profiles(id),
  voucher_code text not null unique,
  service_name text not null,
  status text not null default 'available' check (status in ('available','redeemed','expired','cancelled')),
  expires_at timestamptz,
  redeemed_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists member_orders_owner_idx on public.member_orders(member_id,created_at desc);
create index if not exists cv_ledger_owner_idx on public.cv_ledger(member_id,created_at desc);
create index if not exists rebate_ledger_owner_idx on public.rebate_ledger(member_id,created_at desc);
create index if not exists lv_positions_owner_idx on public.lv_positions(member_id,created_at desc);
create index if not exists member_vouchers_owner_idx on public.member_vouchers(member_id,created_at desc);

-- 新註冊的用戶建立個人資料。推薦碼僅記錄來源，沒有任何自動發獎行為。
create or replace function public.create_member_profile()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_name text;
  v_inviter text;
begin
  v_name := left(coalesce(nullif(trim(new.raw_user_meta_data ->> 'display_name'),''),'009 會員'),80);
  v_inviter := nullif(left(trim(coalesce(new.raw_user_meta_data ->> 'inviter_code','')),32),'');
  insert into public.member_profiles(id,display_name,inviter_code)
  values(new.id,v_name,v_inviter);
  return new;
end; $$;
revoke all on function public.create_member_profile() from public,anon,authenticated;
drop trigger if exists on_009_user_created on auth.users;
create trigger on_009_user_created after insert on auth.users
for each row execute function public.create_member_profile();

-- 帳本原始紀錄禁止改寫或刪除：有錯誤時應另加一筆沖銷或調整。
create or replace function public.reject_ledger_mutation()
returns trigger language plpgsql set search_path = '' as $$
begin
  raise exception '帳務紀錄不得修改或刪除，請另新增調整紀錄';
end; $$;
revoke all on function public.reject_ledger_mutation() from public,anon,authenticated;
drop trigger if exists immutable_cv_ledger on public.cv_ledger;
create trigger immutable_cv_ledger before update or delete on public.cv_ledger
for each row execute function public.reject_ledger_mutation();
drop trigger if exists immutable_rebate_ledger on public.rebate_ledger;
create trigger immutable_rebate_ledger before update or delete on public.rebate_ledger
for each row execute function public.reject_ledger_mutation();

-- RLS：登入會員只能讀自己的資料；沒有會員端可新增或修改帳務的政策。
alter table public.member_profiles enable row level security;
alter table public.member_orders enable row level security;
alter table public.cv_ledger enable row level security;
alter table public.rebate_ledger enable row level security;
alter table public.lv_positions enable row level security;
alter table public.member_vouchers enable row level security;

revoke all on public.member_profiles,public.member_orders,public.cv_ledger,
 public.rebate_ledger,public.lv_positions,public.member_vouchers from anon,authenticated;
grant select on public.member_profiles,public.member_orders,public.cv_ledger,
 public.rebate_ledger,public.lv_positions,public.member_vouchers to authenticated;

drop policy if exists member_self_read on public.member_profiles;
create policy member_self_read on public.member_profiles for select to authenticated
using (id = (select auth.uid()));
drop policy if exists orders_self_read on public.member_orders;
create policy orders_self_read on public.member_orders for select to authenticated
using (member_id = (select auth.uid()));
drop policy if exists cv_self_read on public.cv_ledger;
create policy cv_self_read on public.cv_ledger for select to authenticated
using (member_id = (select auth.uid()));
drop policy if exists rebate_self_read on public.rebate_ledger;
create policy rebate_self_read on public.rebate_ledger for select to authenticated
using (member_id = (select auth.uid()));
drop policy if exists lv_self_read on public.lv_positions;
create policy lv_self_read on public.lv_positions for select to authenticated
using (member_id = (select auth.uid()));
drop policy if exists vouchers_self_read on public.member_vouchers;
create policy vouchers_self_read on public.member_vouchers for select to authenticated
using (member_id = (select auth.uid()));

-- 只有當前登入者自己的摘要；函式是 security invoker，受資料表 RLS 保護。
create or replace function public.my_009_summary()
returns jsonb language sql stable security invoker set search_path = '' as $$
select jsonb_build_object(
 'cv',coalesce((select sum(delta) from public.cv_ledger where member_id=(select auth.uid())),0),
 'credit',coalesce((select sum(delta) from public.rebate_ledger where member_id=(select auth.uid()) and unit='credit'),0),
 'p',coalesce((select sum(delta) from public.rebate_ledger where member_id=(select auth.uid()) and unit='P'),0),
 'rc',coalesce((select sum(delta) from public.rebate_ledger where member_id=(select auth.uid()) and unit='RC'),0),
 'twd',coalesce((select sum(delta) from public.rebate_ledger where member_id=(select auth.uid()) and unit='TWD'),0),
 'orders',coalesce((select count(*) from public.member_orders where member_id=(select auth.uid()) and status='paid'),0),
 'lv_active',coalesce((select count(*) from public.lv_positions where member_id=(select auth.uid()) and status='active'),0),
 'vouchers',coalesce((select count(*) from public.member_vouchers where member_id=(select auth.uid()) and status='available' and (expires_at is null or expires_at > now())),0)
) $$;
revoke all on function public.my_009_summary() from public,anon;
grant execute on function public.my_009_summary() to authenticated;
